import requests

from . import token_opt


def check_param(method, request_url, token_info):
    if method is None:
        raise Exception("请输入请求类型 method")
    if request_url is None:
        raise Exception("请输入请求地址 method")
    if "host_url" not in token_info:
        raise Exception("请在token_info中填充 host_url")
    if not str(token_info["host_url"]).startswith("http"):
        raise Exception("请在token_info中填充 正确的host_url 格式为(http|https)://**.xx")


def check_param_collection(param):
    if param is None:
        return {}
    return param


def check_self_params(token_info):
    if "app_secret" not in token_info:
        raise Exception("请在token_info中填充 app_secret")
    if "app_key" not in token_info:
        raise Exception("请在token_info中填充 app_key")


def check_suit_params(token_info):
    if "suit_secret" not in token_info:
        raise Exception("请在token_info中填充 suit_secret")
    if "suit_key" not in token_info:
        raise Exception("请在token_info中填充 suit_key")
    if "tenant_id" not in token_info:
        raise Exception("请在token_info中填充 tenant_id")


def opt_self_app_request(method, request_url, header, data, params, token_info):
    """
    直接使用内置access_token获取方式调用自建应用业务请求
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param token_info: 获取access_token需要的参数 app_key，app_secret，host_url（token请求域名）
    :return: response
    """
    check_param(method, request_url, token_info)
    check_self_params(token_info)
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    response = token_opt.opt_self_token_with_cache(token_info["app_key"], token_info["app_secret"],
                                                   token_info["host_url"])
    header["access_token"] = response["access_token"]
    params["access_token"] = response["access_token"]
    if 'content-type' in header is False:
        if 'Content-Type' in header is False:
            header['content-type'] = 'application/json; charset=UTF-8'
        else:
            header['content-type'] = header['Content-Type']
    if str(request_url).startswith("/"):
        request_url = token_info["host_url"] + "/iuap-api-gateway" + request_url
    if "post" == method.lower():
        return requests.post(url=request_url, headers=header, data=data, params=params)
    if "get" == method.lower():
        return requests.get(url=request_url, headers=header, params=params)


def opt_suit_request(method, request_url, header, data, params, token_info):
    """
    直接使用内置access_token获取方式调用生态应用业务请求
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param token_info: 获取access_token需要的参数 包括suit_key，suite_secret，tenant_id，host_url（token请求地址）
    :return: response
    """
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    response = token_opt.opt_suit_token_with_cache(token_info["suite_key"], token_info["suite_secret"],
                                                   token_info["tenant_id"],
                                                   token_info["host_url"])
    header["access_token"] = response["access_token"]
    params["access_token"] = response["access_token"]
    if 'content-type' in header is False:
        if 'Content-Type' in header is False:
            header['content-type'] = 'application/json; charset=UTF-8'
        else:
            header['content-type'] = header['Content-Type']
    if str(request_url).startswith("/"):
        request_url = token_info["host_url"] + "/iuap-api-gateway" + request_url
    if "post" == method.lower():
        return requests.post(url=request_url, headers=header, data=data, params=params)
    if "get" == method.lower():
        return requests.get(url=request_url, headers=header, params=params)


def opt_self_app_request_with_access_token(method, request_url, header, data, params, access_token):
    """
    通过access_token 调用自建应用业务请求
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url 请输入完整的http请求地址
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param access_token: access_token
    :return: 接口抵用结果，response
    """
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    header["access_token"] = access_token
    params["access_token"] = access_token
    if 'content-type' in header is False:
        if 'Content-Type' in header is False:
            header['content-type'] = 'application/json; charset=UTF-8'
        else:
            header['content-type'] = header['Content-Type']
    if not str(request_url).startswith("http"):
        raise Exception("请输入以http开头的全路径")
    if "post" == method.lower():
        return requests.post(url=request_url, headers=header, data=data, params=params)
    if "get" == method.lower():
        return requests.get(url=request_url, headers=header, params=params)


def opt_self_app_request_without_cache(method, request_url, header, data, params, token_info):
    """
    使用缓存的access_token 调用自建应用业务请求调用 -- 推荐
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param token_info: 获取access_token需要的参数 app_key，app_secret，host_url（token请求域名）
    :return: response
    """
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    check_param(method, request_url, token_info)
    check_self_params(token_info)
    response = token_opt.opt_self_token(token_info["app_key"], token_info["app_secret"],
                                        token_info["host_url"])
    if str(request_url).startswith("/"):
        request_url = token_info["host_url"] + "/iuap-api-gateway" + request_url
    return opt_self_app_request_with_access_token(method, request_url, header, data, params, response["access_token"])


def opt_suit_request_with_access_token(method, request_url, header, data, params, access_token):
    """
    通过access_token 调用生态应用业务请求
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param access_token: access_token
    :return: 接口抵用结果，response
    """
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    header["access_token"] = access_token
    params["access_token"] = access_token
    if 'content-type' in header is False:
        if 'Content-Type' in header is False:
            header['content-type'] = 'application/json; charset=UTF-8'
        else:
            header['content-type'] = header['Content-Type']
    if not str(request_url).startswith("http"):
        raise Exception("请输入以http开头的全路径")
    if "post" == method.lower():
        return requests.post(url=request_url, headers=header, data=data, params=params)
    if "get" == method.lower():
        return requests.get(url=request_url, headers=header, params=params)


def opt_suit_request_without_cache(method, request_url, header, data, params, token_info):
    """
    使用缓存的access_token 调用生态应用业务请求调用 -- 推荐
    :param method: http请求方式 支持 post get
    :param request_url: 要请求的业务url
    :param header: 业务url请求需要的header业务信息（目前仅默认设置 application/json，和access_token）
    :param data: 业务请求参数
    :param params: url拼接参数
    :param token_info: 获取access_token需要的参数 包括suit_key，suite_secret，tenant_id，host_url（token请求地址）
    :return: response
    """
    header = check_param_collection(header)
    data = check_param_collection(data)
    params = check_param_collection(params)
    check_param(method, request_url, token_info)
    check_suit_params(token_info)
    response = token_opt.opt_suit_token(token_info["suite_key"], token_info["suite_secret"],
                                        token_info["tenant_id"],
                                        token_info["host_url"])
    if str(request_url).startswith("/"):
        request_url = token_info["host_url"] + "/iuap-api-gateway" + request_url
    return opt_suit_request_with_access_token(method, request_url, header, data, params, response["access_token"])
